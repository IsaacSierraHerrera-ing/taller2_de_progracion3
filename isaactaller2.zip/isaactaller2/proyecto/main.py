from clases.animal import Animal
from clases.ave import Ave

ave1 = Ave("LUCHO", 15, 2018, "ISAAC SIERRA")



print(f"Nombre del ave: {ave1.nombre}")
print(f"Peso del ave: {ave1.peso} kg")
print(f"Propietario: {ave1.propietario}")


ave1.calcular_edad()